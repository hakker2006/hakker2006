const logIn = document.querySelector('#login'),
register = document.querySelector('#register'),
btn = document.querySelector('#btn');

function reg(){
logIn.style.left = '-400px';
register.style.left = '50px';
btn.style.left = '110px';
}
function log(){
logIn.style.left = '50px';
register.style.left = '450px';
btn.style.left = '0px';
}